package com.framework.core;

/**
 * Created by suraj on 4/19/2016.
 */
public interface Functor {
    void pre();
    void post();
}
