package com.framework.sampleApp;

import com.framework.core.IPerson;

/**
 * Created by suraj on 4/18/2016.
 */
public class SamplePerson extends IPerson{

    @Override
    public void update() {

    }
}
