package com.framework.core;

/**
 * Created by Bereket on 4/18/2016.
 */
public interface IAccount {

    public double getCurrentBalance();
    public String getAccountNumber();
    public String getType();
    String getPartyType();
}
