package com.framework.sampleApp;

import com.framework.core.IOrganisation;

/**
 * Created by suraj on 4/18/2016.
 */
public class SampleCompany extends IOrganisation {


    @Override
    public void update() {

    }
}
