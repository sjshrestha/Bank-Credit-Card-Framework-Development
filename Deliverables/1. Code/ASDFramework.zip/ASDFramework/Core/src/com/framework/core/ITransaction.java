package com.framework.core;

/**
 * Created by Bereket on 4/18/2016.
 */
public interface ITransaction {
    public boolean compute();
}
