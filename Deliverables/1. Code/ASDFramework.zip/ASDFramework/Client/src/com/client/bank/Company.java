package com.client.bank;

import com.framework.core.IAccount;
import com.framework.core.IOrganisation;

/**
 * Created by suraj on 4/18/2016.
 */
public class Company extends IOrganisation {


    @Override
    public void update() {

    }
}
