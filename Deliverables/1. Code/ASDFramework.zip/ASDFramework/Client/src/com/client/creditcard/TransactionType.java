package com.client.creditcard;

/**
 * Created by Bijay on 4/19/2016.
 */
public enum TransactionType {
    DEPOSIT, WITHDRAW, INTREST;
}
