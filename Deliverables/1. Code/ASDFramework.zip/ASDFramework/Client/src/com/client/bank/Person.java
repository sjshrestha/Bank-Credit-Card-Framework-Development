package com.client.bank;

import com.framework.core.IAccount;
import com.framework.core.IPerson;
import com.framework.core.Party;

/**
 * Created by suraj on 4/18/2016.
 */
public class Person extends IPerson{

    @Override
    public void update() {

    }
}
